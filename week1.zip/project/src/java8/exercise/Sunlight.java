package exercise;

public class Sunlight {
	public static void printTime(float sec) {
		float min = sec / 60;
		sec = sec - (min*60);
		System.out.print(min + " minute(s) and " + sec + " second(s)");
		}
	public static void main(String[] args) {
		
		float kmFromSun = 150000000;
		float lightSpeed = 299792458; 
		
		float mFromSun = kmFromSun*1000;
		float seconds = mFromSun / lightSpeed;
		
		System.out.print("Light will use ");
		printTime(seconds);
		System.out.println(" to travel from the sun to the earth.");
		}
		
		}



