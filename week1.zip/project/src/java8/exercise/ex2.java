package exercise;

public class ex2 {
	double f2c(float fahr) {
		return (fahr - 32) * 5 / 9;

	}


	public static void main(String[] args) {
		float fahrenheit = 62.5f;
		ex2 y=new ex2();
		double celsius = y.f2c(fahrenheit);
		System.out.println(fahrenheit + "F = " + celsius + 'C');
		}


}
