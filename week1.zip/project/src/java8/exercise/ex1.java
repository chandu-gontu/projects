package exercise;

public class ex1{
	int counter;

	public static void main(String[] args) {
		ex1 instance = new ex1();
		instance.go();
	}

	public void go() {
		int sum=0;
		int i = 0;
		while (i < 100) {
			if (i == 0)
				sum = 100;

			sum = sum + i;
			i++;
		}
		System.out.println(sum);
	}
}
