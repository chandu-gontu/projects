package java8;

public class Customer {

	public int withdraw() {
		// TODO Auto-generated method stub
		return 1000;
	}

}
