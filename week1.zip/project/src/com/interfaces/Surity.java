package com.interfaces;

public interface Surity {
	void submitDocs2();

}
