package com.interfaces;

public interface Parking {
	void getSlot();

}
