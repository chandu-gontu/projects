package com.interfaces;

public interface Loan {
	void applyLoan(String name,double amt);

	void submitDocs();

	 int getEmi();
	

}
