package com.excptn;

public class DepostException extends Exception{
	
	DepostException(String msg){
		super(msg);
	}

}
