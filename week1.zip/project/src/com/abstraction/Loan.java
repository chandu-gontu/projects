package com.abstraction;

public abstract class Loan {
	abstract void applyLoan(String name,double amt);
	abstract void submitDocs();
	abstract int getEmi();
	
}
