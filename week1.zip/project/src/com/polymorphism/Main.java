package com.polymorphism;

public class Main {
	
	void sq(int x) {
		System.out.println("area is "+(x*x));
	}

}
