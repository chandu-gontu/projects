package com.collection;

public class MyClass {
	@MyAnnotation()
	public void myAnnotatedMethod() {
		
	}

}
