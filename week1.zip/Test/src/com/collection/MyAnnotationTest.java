package com.collection;

import java.lang.reflect.*;

public class MyAnnotationTest {

	public static void main(String[] args) throws NoSuchMethodException{
		

	}

}
