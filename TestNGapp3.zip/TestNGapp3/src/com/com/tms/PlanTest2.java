package com.com.tms;

import org.testng.annotations.Test;

public class PlanTest2 {
  @Test
  public void f() {
  }
}
